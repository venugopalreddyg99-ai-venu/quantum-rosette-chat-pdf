import os
import tempfile
import streamlit as st
import ollama
import base64
from streamlit_chat import message
from pypdf import PdfReader

# Page configuration for a premium feel
st.set_page_config(page_title="Quantum Rosette - Chat with PDF", layout="wide")

# Custom CSS for modern aesthetics
st.markdown("""
<style>
    .main {
        background-color: #0f172a;
        color: #f8fafc;
    }
    .stButton>button {
        width: 100%;
        border-radius: 8px;
        background: linear-gradient(135deg, #6366f1 0%, #a855f7 100%);
        color: white;
        border: none;
        padding: 10px;
        transition: transform 0.2s;
    }
    .stButton>button:hover {
        transform: scale(1.02);
        box-shadow: 0 4px 15px rgba(168, 85, 247, 0.4);
    }
</style>
""", unsafe_allow_html=True)

# Function to extract text from PDF
def extract_text_from_pdf(pdf_file):
    reader = PdfReader(pdf_file)
    text = ""
    for page in reader.pages:
        text += page.extract_text()
    return text

# Function to display PDF
def display_pdf(file):
    # Reset file pointer for reading
    file.seek(0)
    base64_pdf = base64.b64encode(file.read()).decode('utf-8')
    pdf_display = f'<iframe src="data:application/pdf;base64,{base64_pdf}" width="100%" height="600" type="application/pdf"></iframe>'
    st.markdown(pdf_display, unsafe_allow_html=True)

st.title("📄 Chat with PDF")
st.markdown("### Powered by **Gemma 3:4b** via Ollama")
st.caption("Upload your document and start a conversation with its content.")

# Create a session state to store the chat history and PDF text
if 'messages' not in st.session_state:
    st.session_state.messages = []
if 'pdf_text' not in st.session_state:
    st.session_state.pdf_text = ""

# Sidebar for PDF upload and preview
with st.sidebar:
    st.header("📂 Document Management")
    pdf_file = st.file_uploader("Upload a PDF file", type="pdf")

    # Auto-load demo file if it exists and no file is uploaded
    demo_file_path = os.path.join("data", "sample.pdf")
    if not pdf_file and os.path.exists(demo_file_path):
        if st.button("🚀 Load Demo PDF (sample.pdf)"):
            with st.spinner("Processing demo PDF..."):
                with open(demo_file_path, "rb") as f:
                    st.session_state.pdf_text = extract_text_from_pdf(f)
                st.success("Demo PDF processed! Start chatting below.")

    if pdf_file:
        if st.button("✨ Process Uploaded PDF"):
            with st.spinner("Extracting text from PDF..."):
                st.session_state.pdf_text = extract_text_from_pdf(pdf_file)
            st.success(f"Processed {pdf_file.name} successfully!")
        
        st.subheader("Preview")
        display_pdf(pdf_file)

# Chat interface container
chat_container = st.container()

with chat_container:
    for i, msg in enumerate(st.session_state.messages):
        message(msg["content"], is_user=msg["role"] == "user", key=str(i))

# Input area
if prompt := st.chat_input("Ask a question about the PDF"):
    if not st.session_state.pdf_text:
        st.warning("Please upload and process a PDF first!")
    else:
        st.session_state.messages.append({"role": "user", "content": prompt})
        with chat_container:
            message(prompt, is_user=True)

        with st.spinner("Gemma is thinking..."):
            try:
                # Construct the prompt with a friendly personality
                system_instruction = "You are a helpful AI assistant. Use the provided PDF context to answer the user's questions. Be friendly and conversational. If the answer isn't in the context, you can use your general knowledge, but always prioritize the document and mention if you are using external knowledge."
                context_prompt = f"{system_instruction}\n\nContext from PDF:\n{st.session_state.pdf_text[:10000]}\n\nUser Question: {prompt}"
                
                response = ollama.chat(model='gemma3:4b', messages=[
                    {'role': 'user', 'content': context_prompt},
                ])
                
                assistant_response = response['message']['content']
                st.session_state.messages.append({"role": "assistant", "content": assistant_response})
                with chat_container:
                    message(assistant_response)
            except Exception as e:
                st.error(f"Error communicating with local Gemma model: {str(e)}")

# Sidebar Debug Information
with st.sidebar:
    with st.expander("🛠️ Debug Information"):
        st.write("**Extracted Text Length:**", len(st.session_state.pdf_text))
        if st.session_state.pdf_text:
            st.text_area("Extracted Text Preview:", st.session_state.pdf_text[:500], height=100)
        else:
            st.info("No text extracted yet.")

# Clear chat history button in sidebar
with st.sidebar:
    if st.button("🗑️ Clear Chat History"):
        st.session_state.messages = []
        st.rerun()
